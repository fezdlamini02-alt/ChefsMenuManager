import * as React from 'react';
import { StyleSheet, Text, View, Button, TextInput, FlatList } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

//  Login Screen 
function LoginScreen({ navigation }) {
  const [name, setName] = React.useState('');
  const [password, setPassword] = React.useState('');

  const handleLogin = () => {
    if (!name || !password) {
      alert('Please enter both name and password');
      return;
    }
    navigation.replace('Home'); // go to Home after login
  };

  return (
    <View style={styles.loginContainer}>
    
      <Text style={styles.logo}>F</Text>

      <Text style={styles.loginTitle}>Welcome to Chef’s Menu Manager</Text>

      <TextInput
        style={styles.input}
        placeholder="Name"
        value={name}
        onChangeText={setName}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />

      <Button title="Login" onPress={handleLogin} color="#007BFF" />
    </View>
  );
}

// Home Screen
function HomeScreen({ navigation }) {
  return (
    <View style={styles.homeContainer}>
      <View style={styles.centerContent}>
        <Text style={styles.homeTitle}>Chef’s Menu Manager</Text>
      </View>
      <View style={styles.bottomButton}>
        <Button title="Go to Menu" onPress={() => navigation.navigate('Menu')} color="#007BFF" />
        <View style={{ marginTop: 15 }}>
          <Button title="View History" onPress={() => navigation.navigate('History')} color="#28a745" />
        </View>
      </View>
    </View>
  );
}

// Menu Screen 
function MenuScreen() {
  const [dishName, setDishName] = React.useState('');
  const [description, setDescription] = React.useState('');
  const [course, setCourse] = React.useState('');
  const [price, setPrice] = React.useState('');
  const [menuItems, setMenuItems] = React.useState([]);

  const handleAddItem = () => {
    if (!dishName || !description || !course || !price) {
      alert('All fields are required!');
      return;
    }
    const newItem = { dishName, description, course, price };
    setMenuItems([...menuItems, newItem]);
    setDishName('');
    setDescription('');
    setCourse('');
    setPrice('');
  };

  return (
    <View style={styles.menuContainer}>
      <Text style={styles.title}>Add Menu Item</Text>

      <Text style={styles.label}>Dish Name</Text>
      <TextInput style={styles.input} value={dishName} onChangeText={setDishName} placeholder="Enter dish name" />

      <Text style={styles.label}>Description</Text>
      <TextInput style={styles.input} value={description} onChangeText={setDescription} placeholder="Enter description" />

      <Text style={styles.label}>Course</Text>
      <Picker selectedValue={course} style={styles.picker} onValueChange={(val) => setCourse(val)}>
        <Picker.Item label="Select course" value="" />
        <Picker.Item label="Starter" value="Starter" />
        <Picker.Item label="Main Course" value="Main Course" />
        <Picker.Item label="Dessert" value="Dessert" />
        <Picker.Item label="Beverage" value="Beverage" />
      </Picker>

      <Text style={styles.label}>Price</Text>
      <TextInput style={styles.input} value={price} onChangeText={setPrice} placeholder="Enter price" keyboardType="numeric" />

      <Button title="Add Menu Item" onPress={handleAddItem} />

      <FlatList
        data={menuItems}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>{item.dishName} ({item.course})</Text>
            <Text>{item.description}</Text>
            <Text style={styles.price}>R{item.price}</Text>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.empty}>No menu items yet</Text>}
      />
    </View>
  );
}

// History Screen
function HistoryScreen() {
  const historyItems = [
    { dishName: 'Mussels', description: 'Steamed and dipped in garlic sauce with white wine', course: 'Starter', price: '95' },
    { dishName: 'Grilled Chicken', description: 'Served with veggies & starch of your choice', course: 'Main Course', price: '185' },
    { dishName: 'Chocolate Cake', description: 'Rich and moist', course: 'Dessert', price: '105' },
    { dishName: 'Rockshady', description: 'Smooth, smokey & soft', course: 'Beverage', price: '75' }
  ];

  return (
    <View style={styles.menuContainer}>
      <Text style={styles.title}>History of Added Items</Text>
      <FlatList
        data={historyItems}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>{item.dishName} ({item.course})</Text>
            <Text>{item.description}</Text>
            <Text style={styles.price}>R{item.price}</Text>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.empty}>No history yet</Text>}
      />
    </View>
  );
}

// Navigation
const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Menu" component={MenuScreen} />
        <Stack.Screen name="History" component={HistoryScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// Styles
const styles = StyleSheet.create({
  // Login screen styles
  loginContainer: {
    flex: 1,
    backgroundColor: '#FFF8E7',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 25,
  },
  logo: {
    fontSize: 96,        
    color: '#FF0000',      
    marginBottom: 30,
    fontWeight: 'bold',
  },
  loginTitle: {
    fontSize: 24,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 30,
    color: '#2c3e50',
  },

  // Input styles
  input: {
    width: '100%',
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 12,
    borderRadius: 8,
    marginBottom: 15,
    backgroundColor: '#fff',
  },

  // Home screen styles
  homeContainer: {
    flex: 1,
    backgroundColor: '#FFF8E7',
    justifyContent: 'space-between',
    padding: 25,
  },
  centerContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  homeTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#4B3832',
  },
  bottomButton: {
    marginBottom: 40,
  },

  // Menu & History screen styles
  menuContainer: { flex: 1, padding: 25, backgroundColor: '#fff' },
  title: { fontSize: 28, fontWeight: 'bold', textAlign: 'center', marginBottom: 20 },
  label: { fontSize: 18, fontWeight: '600', marginTop: 15 },
  picker: { borderWidth: 1, borderColor: '#ccc', borderRadius: 8, marginBottom: 15, height: 50 },
  card: { borderWidth: 1, borderColor: '#ddd', padding: 15, marginVertical: 10, borderRadius: 10, backgroundColor: '#f9f9f9' },
  cardTitle: { fontSize: 18, fontWeight: 'bold' },
  price: { marginTop: 5, fontWeight: '600', color: '#27ae60' },
  empty: { textAlign: 'center', marginTop: 20, fontStyle: 'italic', color: '#888' },
});









